/*
 *  /MathJax/jax/output/HTML-CSS/fonts/TeX/Main/Bold/SupplementalArrowsA.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS["MathJax_Main-bold"],{10229:[518,17,1805,64,1741],10230:[518,17,1833,96,1773],10231:[518,17,2126,64,2061],10232:[547,46,1868,64,1804],10233:[547,46,1870,64,1804],10234:[547,46,2126,64,2060],10236:[518,17,1833,65,1773]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/Main/Bold/SupplementalArrowsA.js");

